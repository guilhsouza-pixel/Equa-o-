# Resolvedor de Equação do 2º Grau

Projeto de estudo em HTML, CSS e JavaScript.

## O que o site faz

- Resolve equações no formato `ax² + bx + c = 0`
- Calcula o discriminante `Δ`
- Mostra as raízes reais, quando existirem
- Mostra o vértice da parábola
- Informa a concavidade
- Gera o gráfico da função usando Chart.js

## Como rodar localmente

Abra o arquivo `index.html` no navegador.

Ou use a extensão Live Server no VS Code.

## Como publicar na Vercel

1. Suba o projeto no GitHub.
2. Acesse a Vercel.
3. Clique em **Add New Project**.
4. Importe o repositório.
5. Clique em **Deploy**.

Como é um projeto estático, não precisa configurar build.
