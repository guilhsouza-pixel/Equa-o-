const inputA = document.getElementById('a');
const inputB = document.getElementById('b');
const inputC = document.getElementById('c');
const preview = document.getElementById('preview');
const result = document.getElementById('result');
const calculateBtn = document.getElementById('calculateBtn');
const chartCanvas = document.getElementById('quadraticChart');

let chart;

function formatNumber(value) {
  if (!Number.isFinite(value)) return 'Não existe';
  return Number(value.toFixed(4)).toString();
}

function updatePreview(a, b, c) {
  preview.textContent = `f(x) = ${a}x² ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)}`;
}

function calculateQuadratic() {
  const a = Number(inputA.value);
  const b = Number(inputB.value);
  const c = Number(inputC.value);

  updatePreview(a, b, c);

  if (a === 0) {
    result.innerHTML = `
      <div class="result-line"><strong>Atenção:</strong> o valor de a não pode ser zero.</div>
      <div class="result-line">Quando a = 0, a função deixa de ser uma equação do 2º grau.</div>
    `;
    drawChart(a, b, c);
    return;
  }

  const delta = b ** 2 - 4 * a * c;
  const xv = -b / (2 * a);
  const yv = a * xv ** 2 + b * xv + c;

  let rootsText;

  if (delta > 0) {
    const x1 = (-b + Math.sqrt(delta)) / (2 * a);
    const x2 = (-b - Math.sqrt(delta)) / (2 * a);
    rootsText = `Duas raízes reais: x₁ = ${formatNumber(x1)} e x₂ = ${formatNumber(x2)}`;
  } else if (delta === 0) {
    const x = -b / (2 * a);
    rootsText = `Uma raiz real dupla: x = ${formatNumber(x)}`;
  } else {
    rootsText = 'Não possui raízes reais, pois Δ é negativo.';
  }

  result.innerHTML = `
    <div class="result-line"><strong>Equação:</strong> ${a}x² ${b >= 0 ? '+' : '-'} ${Math.abs(b)}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0</div>
    <div class="result-line"><strong>Δ:</strong> ${formatNumber(delta)}</div>
    <div class="result-line"><strong>Raízes:</strong> ${rootsText}</div>
    <div class="result-line"><strong>Vértice:</strong> (${formatNumber(xv)}, ${formatNumber(yv)})</div>
    <div class="result-line"><strong>Concavidade:</strong> ${a > 0 ? 'para cima' : 'para baixo'}</div>
  `;

  drawChart(a, b, c, xv);
}

function drawChart(a, b, c, centerX = 0) {
  const labels = [];
  const values = [];
  const start = centerX - 10;
  const end = centerX + 10;
  const step = 0.5;

  for (let x = start; x <= end; x += step) {
    const roundedX = Number(x.toFixed(2));
    labels.push(roundedX);
    values.push(a * roundedX ** 2 + b * roundedX + c);
  }

  if (chart) {
    chart.destroy();
  }

  chart = new Chart(chartCanvas, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'f(x)',
        data: values,
        borderWidth: 3,
        tension: 0.25,
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          title: {
            display: true,
            text: 'x'
          }
        },
        y: {
          title: {
            display: true,
            text: 'f(x)'
          }
        }
      },
      plugins: {
        legend: {
          display: true
        },
        tooltip: {
          callbacks: {
            label: context => `f(x) = ${formatNumber(context.parsed.y)}`
          }
        }
      }
    }
  });
}

calculateBtn.addEventListener('click', calculateQuadratic);
[inputA, inputB, inputC].forEach(input => {
  input.addEventListener('input', () => {
    updatePreview(Number(inputA.value), Number(inputB.value), Number(inputC.value));
  });
});

calculateQuadratic();
